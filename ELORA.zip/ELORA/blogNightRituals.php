<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Night Rituals for Radiant Skin | Elora</title>
<style>
  body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f9f7f5;
    color: #333;
    margin: 0;
    line-height: 1.8;
  }
  header {
    text-align: center;
    padding: 50px 20px 20px;
  }
  header h1 {
    font-family: "Playfair Display", serif;
    font-size: 2.6rem;
    margin: 10px 0;
  }
  .meta {
    color: #777;
    font-size: 0.95rem;
  }
  a.back {
    color: #a86c4d;
    text-decoration: none;
    font-size: 0.9rem;
  }
  main {
    max-width: 850px;
    margin: 0 auto 60px;
    background: #fff;
    padding: 30px;
    border-radius: 18px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
  }
  .hero-wrap {
    text-align: center;
    margin: 20px 0 30px;
  }
  .hero-wrap img {
    width: 90%;
    max-width: 450px;        /* limits the width */
    max-height: 450px;       /* limits tall images */
    object-fit: cover;
    border-radius: 14px;
    box-shadow: 0 4px 14px rgba(0,0,0,0.1);
  }
  h2 {
    margin-top: 35px;
    font-family: "Playfair Display", serif;
    color: #444;
  }
  blockquote {
    border-left: 4px solid #d3b497;
    padding-left: 16px;
    color: #555;
    font-style: italic;
    background: #fdf9f5;
    margin: 20px 0;
  }
  ul.checklist {
    list-style: none;
    padding-left: 20px;
  }
  ul.checklist li::before {
    content: "✓ ";
    color: #a86c4d;
  }
</style>
</head>
<body>

<header>
  <a href="../ELORA/index.html" class="back">← Back to Blog</a>
  <h1>Night Rituals for Radiant Skin</h1>
  <p class="meta">By Elora Skincare · September 17, 2025</p>
</header>

<main>
  <div class="hero-wrap">
    <img src="../ELORA/Images/blog night rituals.jpg" alt="Night skincare essentials">
  </div>

  <p>
    Nighttime is when your skin repairs, restores, and regenerates. 
    A carefully crafted bedtime ritual not only pampers the skin 
    but also calms the mind for deep, restorative sleep.
  </p>

  <h2>1. The Evening Reset</h2>
  <p>
    Begin by creating an environment that invites relaxation:
  </p>
  <ul class="checklist">
    <li>Dim the lights and play soft music.</li>
    <li>Light a soothing lavender or sandalwood candle.</li>
    <li>Prepare a warm herbal tea to signal “wind-down mode.”</li>
  </ul>

  <h2>2. Double Cleanse</h2>
  <p>
    A double cleanse ensures every trace of makeup and pollution is removed.
    Start with an oil-based cleanser to dissolve impurities,
    then follow with a gentle, pH-balanced foaming wash.
  </p>
  <blockquote>
    Massage the cleanser for at least 60 seconds to stimulate blood circulation and
    encourage lymphatic drainage.
  </blockquote>

  <h2>3. Targeted Treatments</h2>
  <p>
    Night is prime time for active ingredients that may be sun-sensitive:
  </p>
  <ul class="checklist">
    <li><strong>Retinol</strong> to boost collagen and smooth fine lines.</li>
    <li><strong>Peptide serums</strong> for deep cellular repair.</li>
    <li><strong>Hydrating essences</strong> with hyaluronic acid for lasting moisture.</li>
  </ul>

  <h2>4. Seal with Rich Hydration</h2>
  <p>
    Finish with a nutrient-rich night cream or a few drops of facial oil. 
    Warm the product between your palms and press it gently into the skin 
    to enhance absorption without tugging.
  </p>

  <h2>5. Mind–Skin Connection</h2>
  <p>
    Complete your ritual with a few minutes of mindful breathing, journaling,
    or light stretches. Stress hormones affect skin health; 
    calming the mind supports overnight repair.
  </p>

  <h2>Pro Tips for Extra Glow</h2>
  <ul class="checklist">
    <li>Change pillowcases twice a week to keep bacteria at bay.</li>
    <li>Keep a humidifier running if you sleep in an air-conditioned room.</li>
    <li>Stay hydrated throughout the day to help the skin recover overnight.</li>
  </ul>

  <p>
    By embracing these steps consistently, you’ll wake up to a complexion that
    feels refreshed, balanced, and luminous—your skin’s best version of beauty sleep.
  </p>
</main>

</body>
</html>