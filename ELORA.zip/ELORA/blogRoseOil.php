<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Benefits of Pure Rose Oil | Elora</title>
<style>
  body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f9f7f5;
    color: #333;
    margin: 0;
    line-height: 1.8;
  }
  header {
    text-align: center;
    padding: 50px 20px 20px;
  }
  header h1 {
    font-family: "Playfair Display", serif;
    font-size: 2.6rem;
    margin: 10px 0;
  }
  .meta { color:#777; font-size:0.95rem; }
  a.back {
    color:#a86c4d;
    text-decoration:none;
    font-size:0.9rem;
  }
  main {
    max-width: 850px;
    margin: 0 auto 60px;
    background: #fff;
    padding: 30px;
    border-radius: 18px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
  }
  .hero-wrap { text-align:center; margin:20px 0 30px; }
  .hero-wrap img {
    width:90%; max-width:450px; max-height:450px;
    object-fit:cover;
    border-radius:14px;
    box-shadow:0 4px 14px rgba(0,0,0,0.1);
  }
  h2 {
    margin-top:35px;
    font-family: "Playfair Display", serif;
    color:#444;
  }
  blockquote {
    border-left:4px solid #d3b497;
    padding-left:16px;
    color:#555;
    font-style:italic;
    background:#fdf9f5;
    margin:20px 0;
  }
  ul.checklist {
    list-style:none;
    padding-left:20px;
  }
  ul.checklist li::before {
    content:"✓ ";
    color:#a86c4d;
  }
</style>
</head>
<body>

<header>
  <a href="../ELORA/index.html" class="back">← Back to Blog</a>
  <h1>Benefits of Pure Rose Oil</h1>
  <p class="meta">By Elora Skincare · September 18, 2025</p>
</header>

<main>
  <div class="hero-wrap">
    <img src="../ELORA/Images/blog rose oil.jpg" alt="Rose oil with fresh petals">
  </div>

  <p>
    Distilled from the delicate petals of Rosa Damascena, pure rose oil has been
    cherished for centuries for its unparalleled aroma and powerful skin benefits.
  </p>

  <h2>1. Deep Hydration</h2>
  <p>
    Rose oil is rich in natural emollients that lock in moisture,
    making it perfect for dry or sensitive skin.
  </p>

  <h2>2. Soothing & Balancing</h2>
  <blockquote>
    Its anti-inflammatory properties calm redness and reduce irritation,
    giving your skin a balanced, even-toned appearance.
  </blockquote>

  <h2>3. Anti-Ageing Allies</h2>
  <p>
    Packed with antioxidants like vitamin C and phenols,
    rose oil fights free radicals and supports collagen production.
  </p>

  <h2>How to Use</h2>
  <ul class="checklist">
    <li>Add 2–3 drops to your nightly moisturizer for extra nourishment.</li>
    <li>Mix with a carrier oil for a luxurious facial massage.</li>
    <li>Diffuse a few drops to create a spa-like atmosphere at home.</li>
  </ul>

  <p>
    Incorporate this timeless elixir into your routine and enjoy soft,
    luminous skin with a natural rosy glow.
  </p>
</main>

</body>
</html>